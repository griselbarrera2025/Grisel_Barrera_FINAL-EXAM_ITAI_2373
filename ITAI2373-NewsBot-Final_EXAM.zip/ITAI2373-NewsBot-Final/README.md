# ITAI2373 — NewsBot Intelligence System 2.0 (Final Project)

This repository contains the **production-ready NewsBot 2.0** platform. It builds on the midterm system and adds advanced topic modeling, multilingual intelligence, language-model powered summarization/generation, and a conversational query interface.

> Start in `notebooks/01_Data_Exploration.ipynb` or run the package modules under `src/`.

## Quick Start (Colab or local)
1. `pip install -r requirements.txt`
2. Place datasets under `data/raw/` (e.g., BBC)
3. Run notebooks in order or execute modules via CLI/scripts.
4. Trained artifacts are stored in `data/models/`, results in `data/results/`.

See `docs/user_guide.md` and `docs/deployment_guide.md` for full details.
