"""Semantic embedding utilities for similarity & search (stub)."""
class Embeddings:
    def encode(self, texts):
        return [[0.0] * 3 for _ in texts]
