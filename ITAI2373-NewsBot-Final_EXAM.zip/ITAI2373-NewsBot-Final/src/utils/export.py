"""Report and artifact export helpers (stub)."""
def export_report(data, path):
    with open(path, "w", encoding="utf-8") as f:
        f.write("[report placeholder]\n")
