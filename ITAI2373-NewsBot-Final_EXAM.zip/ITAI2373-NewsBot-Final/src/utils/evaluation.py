"""Evaluation utilities (stub)."""
def classification_report(*args, **kwargs):
    return {}
