"""Visualization helpers (stub)."""
def plot_topics(*args, **kwargs):
    pass
