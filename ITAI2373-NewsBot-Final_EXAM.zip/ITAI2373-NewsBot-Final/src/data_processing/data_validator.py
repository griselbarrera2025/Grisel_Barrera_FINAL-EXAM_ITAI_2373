"""Data validation and schema checks for input corpora."""
class DataValidator:
    def validate(self, df):
        """Validate required columns and basic quality constraints."""
        required = {"text"}
        missing = required - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {missing}")
        return True
