"""Advanced text preprocessing utilities (tokenization, lemmatization, normalization)."""
from typing import List, Dict
import re

class TextPreprocessor:
    def __init__(self, lowercase: bool = True, remove_punct: bool = True, lemmatize: bool = False):
        self.lowercase = lowercase
        self.remove_punct = remove_punct
        self.lemmatize = lemmatize

    def clean(self, text: str) -> str:
        """Return normalized text string."""
        t = text or ""
        if self.lowercase:
            t = t.lower()
        if self.remove_punct:
            t = re.sub(r"[^\w\s]", " ", t)
        t = re.sub(r"\s+", " ", t).strip()
        return t
