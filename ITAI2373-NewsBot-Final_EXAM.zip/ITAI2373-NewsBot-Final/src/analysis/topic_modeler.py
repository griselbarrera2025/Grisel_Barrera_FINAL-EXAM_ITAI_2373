"""LDA/NMF topic modeling utilities."""
from typing import List

class TopicModeler:
    def __init__(self, n_topics: int = 10, method: str = "lda"):
        self.n_topics = n_topics
        self.method = method
        self.model = None

    def fit_transform(self, documents: List[str]):
        """Train topic model and transform documents (stub)."""
        raise NotImplementedError

    def get_topic_words(self, topic_id: int, n_words: int = 10):
        """Return top words for a specific topic (stub)."""
        raise NotImplementedError

    def visualize_topics(self):
        """Create interactive topic visualization (stub)."""
        raise NotImplementedError
