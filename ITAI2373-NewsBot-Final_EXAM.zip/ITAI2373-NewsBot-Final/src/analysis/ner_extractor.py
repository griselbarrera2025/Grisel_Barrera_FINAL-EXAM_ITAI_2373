"""Named Entity Recognition and relationship extraction (stub)."""
class NERExtractor:
    def extract(self, text: str):
        return {"entities": []}
