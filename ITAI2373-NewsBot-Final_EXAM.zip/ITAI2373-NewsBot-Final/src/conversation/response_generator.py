"""Response generation for conversational interface (stub)."""
class ResponseGenerator:
    def generate(self, state) -> str:
        return "[response placeholder]"
