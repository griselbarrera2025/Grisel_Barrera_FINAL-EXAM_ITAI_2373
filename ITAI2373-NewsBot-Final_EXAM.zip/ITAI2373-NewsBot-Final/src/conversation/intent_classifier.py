"""Intent detection for user queries (stub)."""
class IntentClassifier:
    def predict(self, text: str) -> str:
        return "generic_intent"
