"""Language identification utilities (stub)."""
class LanguageDetector:
    def detect(self, text: str) -> str:
        return "en"
