"""Translation service wrapper (stub)."""
class Translator:
    def translate(self, text: str, target_lang: str = "en") -> str:
        return text
