# API Reference (Draft)
Auto-generated or hand-written docs for the `src/` package.
