# Technical Documentation (Draft)
- Architecture overview
- Module APIs
- Install & configuration
- Runtime workflows
