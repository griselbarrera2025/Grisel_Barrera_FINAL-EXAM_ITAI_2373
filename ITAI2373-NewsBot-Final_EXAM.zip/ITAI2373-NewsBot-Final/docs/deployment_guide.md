# Deployment Guide (Draft)
- Local run
- Colab usage
- Optional web app deployment
