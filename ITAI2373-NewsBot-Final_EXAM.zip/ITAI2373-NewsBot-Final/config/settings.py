"""Centralized configuration management for NewsBot 2.0."""
from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
MODELS_DIR = DATA_DIR / "models"
RESULTS_DIR = DATA_DIR / "results"

# Load environment variables for keys (never commit real keys)
NEWS_API_KEY = os.getenv("NEWS_API_KEY", "")
TRANSLATION_API_KEY = os.getenv("TRANSLATION_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")  # if used

# Runtime settings
RANDOM_SEED = int(os.getenv("NEWSBOT_SEED", "42"))
LOG_LEVEL = os.getenv("NEWSBOT_LOG_LEVEL", "INFO")
