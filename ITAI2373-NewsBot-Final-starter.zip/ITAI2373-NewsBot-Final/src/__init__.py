"""
NewsBot 2.0 source package.
"""