"""
Generate final text responses to user queries with context.
"""
def build_response(payload) -> str:
    return "Here are your results."
