"""
Feature extraction utilities:
- TF-IDF
- sentence embeddings (SentenceTransformers)
- custom lexical features
"""
from typing import List, Dict, Any
from sklearn.feature_extraction.text import TfidfVectorizer

class FeatureExtractor:
    def __init__(self):
        self.tfidf = TfidfVectorizer(max_features=20000, ngram_range=(1,2))

    def fit_transform(self, texts: List[str]):
        return self.tfidf.fit_transform(texts)

    def transform(self, texts: List[str]):
        return self.tfidf.transform(texts)
