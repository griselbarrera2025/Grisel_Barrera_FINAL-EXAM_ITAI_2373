"""
Advanced text preprocessing utilities.
- cleaning, normalization
- tokenization, lemmatization
- stopword handling
"""
from typing import List, Iterable, Union, Dict
import re
import nltk

class TextPreprocessor:
    def __init__(self, lowercase: bool = True, remove_punct: bool = True):
        self.lowercase = lowercase
        self.remove_punct = remove_punct

    def clean(self, text: str) -> str:
        if self.lowercase:
            text = text.lower()
        if self.remove_punct:
            text = re.sub(r"[\W_]+", " ", text)
        return text.strip()
