"""
Data quality checks:
- nulls, duplicates, length thresholds
- label distribution
"""
from typing import List, Dict, Any
import pandas as pd

def basic_checks(df: pd.DataFrame, text_col: str, label_col: str = None) -> Dict[str, Any]:
    report = {}
    report["n_rows"] = len(df)
    report["n_null_text"] = df[text_col].isna().sum()
    report["n_duplicates"] = df.duplicated(subset=[text_col]).sum()
    if label_col and label_col in df.columns:
        report["label_counts"] = df[label_col].value_counts().to_dict()
    return report
