"""
Sentence/semantic embeddings.
"""
from typing import List

class Embeddings:
    def encode(self, texts: List[str]):
        # TODO: use SentenceTransformers
        return [[0.0] * 384 for _ in texts]
