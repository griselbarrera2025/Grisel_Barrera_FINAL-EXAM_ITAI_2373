"""
Abstractive summarization wrapper (e.g., BART/T5).
"""
from typing import List

class Summarizer:
    def summarize(self, texts: List[str], max_length: int = 128):
        # TODO: integrate transformers pipeline
        return ["<summary>" for _ in texts]
