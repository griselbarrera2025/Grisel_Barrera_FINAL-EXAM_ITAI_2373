"""
Report generation/export helpers (PDF/HTML/CSV).
"""
def export_placeholder():
    return True
