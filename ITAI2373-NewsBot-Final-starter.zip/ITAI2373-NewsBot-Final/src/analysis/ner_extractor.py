"""
Named Entity Recognition & entity relationship mapping.
"""
from typing import List, Dict
import spacy

class NERExtractor:
    def __init__(self, model: str = "en_core_web_sm"):
        self.nlp = spacy.load(model)

    def extract(self, text: str) -> List[Dict]:
        doc = self.nlp(text)
        return [{"text": ent.text, "label": ent.label_} for ent in doc.ents]
