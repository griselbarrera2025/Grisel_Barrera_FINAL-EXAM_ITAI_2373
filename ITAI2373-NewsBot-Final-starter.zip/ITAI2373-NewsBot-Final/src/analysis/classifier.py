"""
Enhanced classification system supporting TF-IDF and embeddings.
"""
from typing import List, Dict, Any
from sklearn.linear_model import LogisticRegression

class NewsClassifier:
    def __init__(self):
        self.model = LogisticRegression(max_iter=200)

    def fit(self, X, y):
        self.model.fit(X, y)
        return self

    def predict(self, X):
        return self.model.predict(X)

    def predict_proba(self, X):
        if hasattr(self.model, "predict_proba"):
            return self.model.predict_proba(X)
        return None
