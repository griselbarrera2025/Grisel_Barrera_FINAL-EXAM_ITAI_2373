# NewsBot 2.0 – Final Project (ITAI 2373)

This repository contains a production-ready upgrade of the midterm **NewsBot Intelligence System**.
It implements advanced NLP features: topic modeling (LDA/NMF), multilingual analysis, summarization,
semantic search, conversational interface, and professional documentation.

> **Owner:** Grisel Barrera  
> **Course:** ITAI 2373 — NLP  
> **Created:** 2025-08-07

## Quick Start (Local)
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

## Project Structure
```
ITAI2373-NewsBot-Final/
├── README.md
├── requirements.txt
├── config/
│   ├── settings.py
│   └── api_keys_template.txt
├── src/
│   ├── data_processing/
│   ├── analysis/
│   ├── language_models/
│   ├── multilingual/
│   ├── conversation/
│   └── utils/
├── notebooks/
├── tests/
├── data/
│   ├── raw/
│   ├── processed/
│   ├── models/
│   └── results/
├── docs/
└── reports/
```

## How to Run End-to-End (Colab)
Open `notebooks/07_System_Integration.ipynb` in Google Colab and follow the cells to:
1) Load data → 2) Preprocess → 3) Classify → 4) Topic Model → 5) Summarize → 6) Translate/Compare → 7) Query

## Midterm → Final Mapping
See `docs/midterm_to_final_mapping.md` for a direct mapping of your midterm components into this structure.
