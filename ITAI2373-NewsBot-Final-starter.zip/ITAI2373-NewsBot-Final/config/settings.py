"""
Project-wide configuration settings.

Edit these defaults or override via environment variables.
"""
import os

DATA_DIR = os.getenv("NEWSBOT_DATA_DIR", "data")
MODEL_DIR = os.getenv("NEWSBOT_MODEL_DIR", "data/models")
RESULTS_DIR = os.getenv("NEWSBOT_RESULTS_DIR", "data/results")
LOG_LEVEL = os.getenv("NEWSBOT_LOG_LEVEL", "INFO")
RANDOM_SEED = int(os.getenv("NEWSBOT_RANDOM_SEED", "42"))
