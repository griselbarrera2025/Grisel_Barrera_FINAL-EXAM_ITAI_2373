# User Guide

## Typical Workflows
1. **Single Article Analysis**: preprocess → classify → summarize → entities → sentiment
2. **Batch Analysis**: run notebook `07_System_Integration.ipynb`
3. **Multilingual**: detect language, translate if needed, compare topic distributions

## Troubleshooting
- If spaCy model missing: `python -m spacy download en_core_web_sm`
- GPU optional for transformers; CPU works but slower.
