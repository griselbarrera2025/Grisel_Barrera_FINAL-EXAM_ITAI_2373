# Technical Documentation

## Architecture Overview
- `src/data_processing`: preprocessing, feature extraction, validation
- `src/analysis`: classification, sentiment, NER, topic modeling
- `src/language_models`: summarization, generation, embeddings
- `src/multilingual`: language detection, translation, cross-lingual analysis
- `src/conversation`: intents, query processing, responses
- `src/utils`: visualization, evaluation, export

## Setup
See `README.md` for environment setup and `requirements.txt` for dependencies.

## API Reference
Inline docstrings provided in each module.
