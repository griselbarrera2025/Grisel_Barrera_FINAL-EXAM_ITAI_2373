# Midterm → Final Mapping

| Midterm Asset | Final Path | Notes |
|---|---|---|
| `preprocessing.py` | `src/data_processing/text_preprocessor.py` | Move cleaning/tokenization here. |
| `features.py` | `src/data_processing/feature_extractor.py` | Keep TF-IDF; add embeddings later. |
| `classifier.ipynb` | `notebooks/02_Advanced_Classification.ipynb` | Convert training steps to functions in `src/analysis/classifier.py`. |
| `sentiment.py` | `src/analysis/sentiment_analyzer.py` | Replace with transformer pipeline later. |
| `ner.py` | `src/analysis/ner_extractor.py` | Use spaCy; add relationship graphing. |
| `topic_modeling.ipynb` | `src/analysis/topic_modeler.py` & `notebooks/03_Topic_Modeling.ipynb` | Implement LDA & NMF. |
| `README.md` | top-level `README.md` | Expand with setup, usage, and structure. |
