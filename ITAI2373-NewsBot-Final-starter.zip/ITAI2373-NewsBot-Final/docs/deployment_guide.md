# Deployment Guide

## Local
- Create virtualenv and install requirements.
- Run notebooks or build a small CLI around `src/` modules.

## Optional Flask App
- Create `app.py` and wire modules (see assignment sample).
- Deploy to Heroku/Render/railway.app or run locally with `flask run`.
