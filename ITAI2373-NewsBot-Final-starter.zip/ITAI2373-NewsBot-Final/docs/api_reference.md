# API Reference

See docstrings in `src/` modules. Public entry points:
- `TextPreprocessor.clean`
- `FeatureExtractor.fit_transform/transform`
- `NewsClassifier.fit/predict/predict_proba`
- `NERExtractor.extract`
- `TopicModeler.fit_transform/get_topic_words/visualize_topics`
- `Summarizer.summarize`
- `ContentGenerator.generate`
- `Embeddings.encode`
- `detect_language`, `translate`
- `IntentClassifier.predict`
- `QueryProcessor.process`
- `build_response`
