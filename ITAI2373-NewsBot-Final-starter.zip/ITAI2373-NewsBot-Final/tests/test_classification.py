import unittest
from src.analysis.classifier import NewsClassifier
import numpy as np
from scipy.sparse import csr_matrix

class TestClassification(unittest.TestCase):
    def test_fit_predict(self):
        X = csr_matrix(np.array([[0,1],[1,0],[1,1]]))
        y = np.array([0,1,1])
        clf = NewsClassifier().fit(X, y)
        preds = clf.predict(X)
        self.assertEqual(len(preds), 3)

if __name__ == "__main__":
    unittest.main()
