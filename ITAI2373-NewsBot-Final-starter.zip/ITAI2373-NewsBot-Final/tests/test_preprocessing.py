import unittest
from src.data_processing.text_preprocessor import TextPreprocessor

class TestPreprocessing(unittest.TestCase):
    def test_clean(self):
        tp = TextPreprocessor()
        self.assertEqual(tp.clean("Hello, World!"), "hello world")

if __name__ == "__main__":
    unittest.main()
